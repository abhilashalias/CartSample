using GenericCompany.Entities;
using GenericCompany.Entities.Physical;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GenericCompany.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void PhysicalItem_Payment_Success()
        {
            GenericProduct product = new GenericProduct(new PhysicalProduct());
            product.ProductId = "001";
            product.ProductName = "Furniture";
            product.Status = "A";
            product.Description = "Furniture for Home";
            var result = product.ProductCategory.GetPaymentInfo();

            // These will be replaced by status codes in actual code.
            Assert.AreEqual("Generating packaging slip...Generating commission payment...", result);
        }
    }
}
