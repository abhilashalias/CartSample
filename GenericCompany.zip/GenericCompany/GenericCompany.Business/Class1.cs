﻿using System;

namespace GenericCompany.Business
{
    public class Class1
    {
    }
}
