﻿using GenericCompany.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCompany.Entities.Subscriptions
{
    public class SubscriptionItem : ICategory
    {
        public string ProductType { get { return "SUBSCRIPTION"; } }
        public bool IsNewSubscriber { get; set; }

        public string GetPaymentInfo()
        {
            string task = string.Empty;
            PerformPaymentTasks().ForEach(x => task += x);
            return task;
        }

        private List<string> PerformPaymentTasks()
        {
            List<string> paymentsTasks = new List<string>();

            paymentsTasks.Add("Generating packaging slip...");
            if (IsNewSubscriber)
            {
                paymentsTasks.Add("Activating membership...");
            }
            else
            {
                paymentsTasks.Add("Updating membership...");
            }
            return paymentsTasks;
        }
    }
}
