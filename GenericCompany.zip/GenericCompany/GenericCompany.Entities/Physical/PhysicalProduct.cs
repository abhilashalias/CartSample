﻿using GenericCompany.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace GenericCompany.Entities.Physical
{
    public class PhysicalProduct : ICategory
    {
        public string ProductType { get { return "PHYSICAL"; } }

        public string GetPaymentInfo()
        {
            string task = string.Empty;
            PerformPaymentTasks().ForEach(x => task += x);
            return task;
        }


        //These will be actual payment tasks. We can also decouple it into a different payment package.
        private List<string> PerformPaymentTasks()
        {
            List<string> paymentsTasks = new List<string>();

            paymentsTasks.Add("Generating packaging slip...");
            paymentsTasks.Add("Generating commission payment...");
            return paymentsTasks;
        }
    }
}
