﻿using GenericCompany.Entities.Interfaces;
using System;

namespace GenericCompany.Entities
{
    public class GenericProduct : IProduct<ICategory>
    {
        public GenericProduct(ICategory category)
        {
            ProductCategory = category;
        }
        public string ProductId { get; set; }
        public string ProductName { get; set; }
        public string Description { get; set; }
        public string Status { get; set; }
        public ICategory ProductCategory { get; set; }
    }
}
