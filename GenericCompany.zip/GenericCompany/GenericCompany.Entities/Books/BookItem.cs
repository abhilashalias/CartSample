﻿using GenericCompany.Entities.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCompany.Entities.Books
{
    public class BookItem : ICategory
    {
        public string ProductType { get { return "BOOK"; } }
        public string GetPaymentInfo()
        {
            string task = string.Empty;
            PerformPaymentTasks().ForEach(x => task += x);
            return task;
        }

        private List<string> PerformPaymentTasks()
        {
            List<string> paymentsTasks = new List<string>();

            paymentsTasks.Add("Generating packaging slip...");
            paymentsTasks.Add("Generating commission payment...");
            paymentsTasks.Add("Generating duplicate slip for royalty...");
            return paymentsTasks;
        }
    }
}
