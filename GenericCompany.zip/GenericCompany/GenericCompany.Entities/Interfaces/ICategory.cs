﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCompany.Entities.Interfaces
{
    public interface ICategory
    {
        string ProductType { get; }
        string GetPaymentInfo();
    }
}
