﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericCompany.Entities.Interfaces
{
    public interface IProduct<ICategory>
    {
        string ProductId { get; set; }
        string ProductName { get; set; }
        string Description { get; set; }
        string Status { get; set; }

        ICategory ProductCategory { get; set; }
    }
}
